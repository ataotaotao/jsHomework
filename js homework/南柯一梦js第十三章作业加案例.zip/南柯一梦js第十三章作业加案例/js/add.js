/**
 *
 * @authors Your Name (you@example.org)
 * @date    2018-02-06 10:58:56
 * @version $Id$
 */
 //添0
 function add(num){
    return num= num>=10?num:'0'+num;
 }

